<template>
    <div>
        奖惩规则
    </div>
</template>

<script>
    export default {
        name: "EcMana"
    }
</script>

<style scoped>

</style>