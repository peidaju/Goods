package org.javaboy.mailserver;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MailserverApplicationTests {

    @Test
    void contextLoads() {
    }

}